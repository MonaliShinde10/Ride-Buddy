export const environment = {
  firebase: {
    projectId: 'car-pooling-b4b33',
    appId: '1:824289701616:web:6f9f9947ca49a78d5e5c35',
    databaseURL: 'https://car-pooling-b4b33-default-rtdb.asia-southeast1.firebasedatabase.app',
    storageBucket: 'car-pooling-b4b33.appspot.com',
    apiKey: 'AIzaSyAU8M9dLEVCX83E7CP2xsIYElMHIKGy4fk',
    authDomain: 'car-pooling-b4b33.firebaseapp.com',
    messagingSenderId: '824289701616',
  },
};